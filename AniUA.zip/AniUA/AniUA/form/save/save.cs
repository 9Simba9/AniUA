﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AniUA.form.save
{
    public partial class save : Form
    {
        string connectionString = "server=localhost;port=3306;username=root;password=root;database=aniua";
        private Font NAMUFont;

        int userID = int.Parse(Properties.Settings.Default.UserID);
        public save()
        {
            InitializeComponent();
            NAMUFont = new Font("NAMU 1750", 14);

            //розгортання вікна на весь екран
            this.WindowState = FormWindowState.Maximized;

            //підкруслення "Збережені" в Закладках
            Font currentFont = label3.Font;
            label3.Font = new Font(currentFont.FontFamily, currentFont.Size, FontStyle.Underline);

            Font currentFont1 = label4.Font;
            label4.Font = new Font(currentFont1.FontFamily, currentFont1.Size, FontStyle.Underline);
        }

        private void save_Load(object sender, EventArgs e)
        {
            LoadAnimeSaves();
        }

        private void LoadAnimeSaves()
        {
            //Очистити попередні коментарі
            flowPanelAnime.Controls.Clear();

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT * FROM anime " +
                               "INNER JOIN in_list ON anime.ID_anime = in_list.ID_anime " +
                               "WHERE in_list.ID_user = @userID AND in_list.save = 'Збережено'";

                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@userID", userID);

                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            //Отримати дані аніме з результуючого рядка
                            int animeID = reader.GetInt32("ID_anime");
                            string animeName = reader.GetString("name");
                            byte[] logo = (byte[])reader["logo"];

                            //Створеня об'єкту Image з масиву байтів logo, для зображення
                            using (MemoryStream ms = new MemoryStream(logo))
                            {
                                Image image = Image.FromStream(ms);

                                //Виведення даних аніме
                                Panel newPanel = new Panel
                                {
                                    BackColor = Color.FromArgb(36, 36, 36),
                                    Width = 286,
                                    Height = 438,
                                    Margin = new Padding(14, 18, 14, 18),
                                    AutoSize = false,
                                    MaximumSize = new Size(286, int.MaxValue),
                                    Name = "Panel_ID" + animeID,
                                    Cursor = Cursors.Hand
                                };

                                PictureBox newImg = new PictureBox
                                {
                                    Width = 286,
                                    Height = 402,
                                    BackColor = Color.FromArgb(36, 36, 36),
                                    SizeMode = PictureBoxSizeMode.Zoom,
                                    Image = image,
                                    Name = "Img_ID" + animeID,
                                    Cursor = Cursors.Hand
                                };

                                Label newText = new Label
                                {
                                    Font = NAMUFont,
                                    ForeColor = Color.White,
                                    Location = new Point(0, 405),
                                    AutoSize = true,
                                    Text = animeName,
                                    Name = "Text_ID" + animeID,
                                    Cursor = Cursors.Hand
                                };

                                //Додавання обробник події Click до newImg
                                newImg.Click += (sender, e) => {
                                    CheckClickedElementName(sender, e);

                                    LoadAnime OpenLoadAnime = new LoadAnime();
                                    OpenLoadAnime.Show();

                                    this.Hide();
                                };

                                //Додавання обробник події Click до newText
                                newText.Click += (sender, e) => {
                                    CheckClickedElementName(sender, e);

                                    LoadAnime OpenLoadAnime = new LoadAnime();
                                    OpenLoadAnime.Show();

                                    this.Hide();
                                };

                                //Додавання обробник події Click до newPanel
                                newPanel.Click += (sender, e) => {
                                    CheckClickedElementName(sender, e);

                                    LoadAnime OpenLoadAnime = new LoadAnime();
                                    OpenLoadAnime.Show();

                                    this.Hide();
                                };

                                string editText = TruncateText(newText.Text);
                                newText.Text = editText;

                                newPanel.Controls.Add(newImg);
                                newPanel.Controls.Add(newText);

                                flowPanelAnime.Controls.Add(newPanel);
                            }
                        }
                    }
                }

                connection.Close();
            }
        }

        //Функція для перевірки ID елементу
        private void CheckClickedElementName(object sender, EventArgs e)
        {
            Control clickedControl = sender as Control;
            if (clickedControl != null)
            {
                string elementName = clickedControl.Name;
                int index = elementName.IndexOf("_ID");
                if (index != -1 && index + 3 < elementName.Length)
                {
                    string id = elementName.Substring(index + 3);
                    Properties.Settings.Default.AnimeID = id;
                    Properties.Settings.Default.Save();
                }
                else
                {
                    MessageBox.Show("Ім'я елемента не знайдено.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        //Функція для назви...
        private string TruncateText(string text)
        {
            const int maxLength = 28;

            if (text.Length <= maxLength)
            {
                return text;
            }
            else
            {
                string truncatedText = text.Substring(0, maxLength - 4) + "...";
                return truncatedText;
            }
        }

        private void buttClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void buttTurn_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void MouseEnter(object sender, EventArgs e)
        {
            if (sender is Label)
            {
                Label label = (Label)sender;
                Font currentFont = label.Font;
                label.Font = new Font(currentFont.FontFamily, currentFont.Size, FontStyle.Underline);
            }
        }

        private void MouseLeave(object sender, EventArgs e)
        {
            if (sender is Label)
            {
                Label label = (Label)sender;
                Font currentFont = label.Font;
                label.Font = new Font(currentFont.FontFamily, currentFont.Size, FontStyle.Regular);
            }
        }

        private void catO_Click(object sender, EventArgs e)
        {
            abandoned abandoned = new abandoned();
            abandoned.Show();
            this.Hide();
        }

        private void label13_Click_1(object sender, EventArgs e)
        {
            AniUA.main OpenMain = new AniUA.main();
            OpenMain.Show();
            this.Hide();
        }

        private void label2_Click_1(object sender, EventArgs e)
        {
            watch OpenWatch = new watch();
            OpenWatch.Show();
            this.Hide();
        }

        private void label1_Click_1(object sender, EventArgs e)
        {
            planned planned = new planned();
            planned.Show();
            this.Hide();
        }

        private void catT_Click_1(object sender, EventArgs e)
        {
            revised revised = new revised();
            revised.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            postponed postponed = new postponed();
            postponed.Show();
            this.Hide();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            user OpenUser = new user();
            OpenUser.Show();
            this.Hide();
        }

        private void search_TextChanged(object sender, EventArgs e)
        {
            SearchAnimeSaves();
        }

        private void SearchAnimeSaves()
        {
            //Очистити попередні коментарі
            flowPanelAnime.Controls.Clear();

            string searchText = search.Text; //Отримати текст для пошуку

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT * " +
                    "FROM anime " +
                    "INNER JOIN in_list ON anime.ID_anime = in_list.ID_anime " +
                    "WHERE (anime.name LIKE @searchText OR anime.original_name LIKE @searchText) " +
                    "AND in_list.ID_user = @userID " +
                    "AND in_list.save = 'Збережено'";

                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@searchText", "%" + searchText + "%");
                    command.Parameters.AddWithValue("@userID", userID);

                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            int animeID = reader.GetInt32("ID_anime");
                            string animeName = reader.GetString("name");
                            byte[] logo = (byte[])reader["logo"];

                            //Створення об'єкту Image з масиву байтів logo, для зображення
                            using (MemoryStream ms = new MemoryStream(logo))
                            {
                                Image image = Image.FromStream(ms);

                                Panel newPanel = new Panel
                                {
                                    BackColor = Color.FromArgb(36, 36, 36),
                                    Width = 286,
                                    Height = 438,
                                    Margin = new Padding(14, 18, 14, 18),
                                    AutoSize = false,
                                    MaximumSize = new Size(286, int.MaxValue),
                                    Name = "Panel_ID" + animeID,
                                    Cursor = Cursors.Hand
                                };

                                PictureBox newImg = new PictureBox
                                {
                                    Width = 286,
                                    Height = 402,
                                    BackColor = Color.FromArgb(36, 36, 36),
                                    SizeMode = PictureBoxSizeMode.Zoom,
                                    Image = image,
                                    Name = "Img_ID" + animeID,
                                    Cursor = Cursors.Hand
                                };

                                Label newText = new Label
                                {
                                    Font = NAMUFont,
                                    ForeColor = Color.White,
                                    Location = new Point(0, 405),
                                    AutoSize = true,
                                    Text = animeName,
                                    Name = "Text_ID" + animeID,
                                    Cursor = Cursors.Hand
                                };

                                newImg.Click += (sender, e) => {
                                    CheckClickedElementName(sender, e);

                                    LoadAnime OpenLoadAnime = new LoadAnime();
                                    OpenLoadAnime.Show();

                                    this.Hide();
                                };

                                newText.Click += (sender, e) => {
                                    CheckClickedElementName(sender, e);

                                    LoadAnime OpenLoadAnime = new LoadAnime();
                                    OpenLoadAnime.Show();

                                    this.Hide();
                                };

                                newPanel.Click += (sender, e) => {
                                    CheckClickedElementName(sender, e);

                                    LoadAnime OpenLoadAnime = new LoadAnime();
                                    OpenLoadAnime.Show();

                                    this.Hide();
                                };

                                string editText = TruncateText(newText.Text); newText.Text = editText;

                                newPanel.Controls.Add(newImg);
                                newPanel.Controls.Add(newText);

                                flowPanelAnime.Controls.Add(newPanel);
                            }
                        }
                    }
                }

                connection.Close();
            }
        }
    }
}
